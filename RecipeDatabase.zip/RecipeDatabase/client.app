FROM nginx:alpine
RUN rm /etc/nginx/conf.d/default.conf
COPY nginx.conf /etc/nginx/conf.d/default.conf
COPY client /usr/share/nginx/html
EXPOSE 8080
CMD ["nginx", "-g", "daemon off;"]
